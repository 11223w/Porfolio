Put your interview video here, named: interview.mp4

- Supported: .mp4 (best) or .webm
- GitHub's website upload accepts files up to 25 MB. For a bigger or longer video,
  upload it to YouTube and paste the link into interview.html (data-youtube="...").
